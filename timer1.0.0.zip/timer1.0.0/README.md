按下"main.exe"運行爆炸遊戲
官方discord群組:https://discord.gg/WACCK3mbm2
作者:discord:ethanlau#2560
支援:windows10/11
由Efactory app©所有
版權所有，翻印必究
名字:到數機
發行日期:2023年1月8日
發行版本:1.0.0
價錢:免費